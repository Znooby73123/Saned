import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  I18nManager,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import Icon from "react-native-vector-icons/Ionicons";
import { router } from "expo-router";

// Correct component import (capitalize it)
import ForgetPassPhone from "@/components/forgetPassPhone";

export default function ChooseResetMethodScreen() {
  const [showForgetPassPhone, setShowForgetPassPhone] = useState(false);

  // Enforce RTL only if not already done
  useEffect(() => {
    if (!I18nManager.isRTL) {
      I18nManager.forceRTL(true);
    }
  }, []);

  if (showForgetPassPhone) {
    return <ForgetPassPhone onBack={() => setShowForgetPassPhone(false)} />;
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => router.push("/sign-in")}
      >
        <Icon name="arrow-back" size={24} color="#000" /> {/* RTL arrow */}
      </TouchableOpacity>

      <Text style={styles.title}>نسيت كلمة المرور</Text>
      <Text style={styles.subtitle}>
        حدد طريقة الاتصال التي تريد استخدامها لإعادة ضبط كلمة المرور
      </Text>

      {/* Phone Option */}
      <TouchableOpacity
        style={styles.option}
        onPress={() => setShowForgetPassPhone(true)}
      >
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>💬</Text>{" "}
          {/* Wrap the emoji inside a Text component */}
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.methodTitle}>عبر الهاتف</Text>
          <Text style={styles.methodSub}>+966****3665</Text>
        </View>
      </TouchableOpacity>

      {/* Email Option */}
      <TouchableOpacity
        style={styles.option}
        onPress={() => console.log("Email Option Pressed")}
      >
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>📧</Text>{" "}
          {/* Wrap the emoji inside a Text component */}
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.methodTitle}>عبر البريد الإلكتروني</Text>
          <Text style={styles.methodSub}>Sup***raj@gmail.com</Text>
        </View>
      </TouchableOpacity>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 100,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
  },
  backButton: {
    position: "absolute",
    top: 70,
    // right: 20, // RTL fix
    // left: 20,
    zIndex: 1,
    padding: 16,
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 60,
  },
  subtitle: {
    fontSize: 22,
    textAlign: "center",
    marginBottom: 100,
    color: "#555",
  },
  option: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "#FFF6E0",
    padding: 15,
    borderRadius: 16,
    marginBottom: 20,
  },
  iconContainer: {
    backgroundColor: "#FFD365",
    borderRadius: 30,
    width: 48,
    height: 48,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 15,
  },
  icon: {
    fontSize: 22,
  },
  textContainer: {
    flex: 1,
  },
  methodTitle: {
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "right",
  },
  methodSub: {
    fontSize: 14,
    color: "#666",
    textAlign: "right",
    marginTop: 2,
  },
});
