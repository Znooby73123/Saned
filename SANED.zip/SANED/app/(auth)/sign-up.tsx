import { Link, router } from "expo-router";
import React, { useState } from "react";
import {
  Text,
  View,
  Alert,
  ActivityIndicator,
  ScrollView,
  I18nManager,
  StyleSheet,
} from "react-native";
import CustomButton from "@/components/CustomButton";
import InputField from "@/components/InputField";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/includes/FirebaseConfig";

const SignUp = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    if (email === "" || password === "") {
      Alert.alert("خطأ", "الرجاء إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }

    if (password.length < 6) {
      Alert.alert("خطأ", "يجب أن تتكون كلمة المرور من 6 أحرف على الأقل");
      return;
    }

    setLoading(true);
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      router.push("/interest");
    } catch (error: any) {
      let errorMessage = "فشل التسجيل";
      if (error.code === "auth/email-already-in-use") {
        errorMessage = "البريد الإلكتروني قيد الاستخدام بالفعل";
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "عنوان بريد إلكتروني غير صالح";
      }
      Alert.alert("خطأ", errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView
      style={styles.scrollView}
      contentContainerStyle={styles.container}
    >
      <View style={styles.innerContainer}>
        <View style={styles.topSpace} />
        <View style={styles.content}>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>تسجيل مستخدم جديد</Text>
          </View>
          <View style={styles.spacing} />
          <InputField
            label="الاسم"
            placeholder="ادخل الاسم"
            style={styles.input}
            labelStyle={styles.label}
            placeholderStyle={styles.placeholder}
            // icon={icons.person}
            // value={form.name}
            // onChangeText={(value) => setForm({ ...form, name: value })}
          />
          <InputField
            label="الايميل"
            placeholder="ادخل الايميل"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            textContentType="emailAddress"
            style={styles.input}
            labelStyle={styles.label}
            placeholderStyle={styles.placeholder}
          />
          <InputField
            label="كلمه المرور"
            secureTextEntry={true}
            textContentType="password"
            placeholder="ادخل كلمه المرور"
            value={password}
            onChangeText={setPassword}
            style={styles.input}
            labelStyle={styles.label}
            placeholderStyle={styles.placeholder}
          />
          <View style={styles.spacing} />
          <CustomButton
            title="تسجيل"
            onPress={handleSignup}
            disabled={loading}
            style={styles.signupButton}
            bgVariant={"yellow"}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>تسجيل</Text>
            )}
          </CustomButton>

          {/*<CustomButton*/}
          {/*  title="تسجيل"*/}
          {/*  onPress={() => router.push("/interest)")}*/}
          {/*  disabled={loading}*/}
          {/*  style={styles.signupButton}*/}
          {/*  bgVariant={"yellow"}*/}
          {/*></CustomButton>*/}
          {/*<OAuth />*/}
          <Link href="/sign-in" style={styles.loginLink}>
            هل لديك حساب بالفعل؟{" "}
            <Text style={styles.loginLinkText}>تسجيل الدخول</Text>
          </Link>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: "white",
  },
  container: {
    flexGrow: 1,
  },
  innerContainer: {
    flex: 1,
  },
  topSpace: {
    height: 60,
  },
  content: {
    paddingHorizontal: 24,
    paddingTop: 80,
  },
  titleContainer: {
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  title: {
    fontSize: 30,
    color: "black",
    fontWeight: "bold",
    fontFamily: "JakartaSemiBold", // Make sure this font is available
    textAlign: "right",
  },
  spacing: {
    paddingVertical: 16,
  },
  label: {
    textAlign: "right",
    marginBottom: 8,
    color: "black",
  },
  input: {
    textAlign: "right",
  },
  placeholder: {
    textAlign: "right",
  },
  signupButton: {
    marginTop: 24,
  },
  buttonText: {
    textAlign: "center",
    color: "white",
  },
  loginLink: {
    fontSize: 16,
    textAlign: "center",
    color: "#777",
    marginTop: 40,
  },
  loginLinkText: {
    color: "#FF914D",
  },
});

export default SignUp;
