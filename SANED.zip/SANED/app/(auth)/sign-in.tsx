import { Link, useRouter } from "expo-router";
import {
  StyleSheet,
  ActivityIndicator,
  Alert,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  I18nManager,
} from "react-native";
import InputField from "@/components/InputField";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "@/includes/FirebaseConfig";
import { useState, useEffect } from "react";
import CustomButton from "@/components/CustomButton";

// Enforce RTL if not already
I18nManager.forceRTL(true);

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Check if user is authenticated
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        router.push("../(root)/(tabs)/home");
      }
    });
    return () => unsubscribe();
  }, [router]);

  const handleLogin = async () => {
    if (email === "" || password === "") {
      Alert.alert("خطأ", "يرجى إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      let errorMessage = "فشل تسجيل الدخول";
      if (
        error.code === "auth/user-not-found" ||
        error.code === "auth/wrong-password"
      ) {
        errorMessage = "البريد الإلكتروني أو كلمة المرور غير صحيحة";
      }
      Alert.alert("خطأ", errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "white" }}>
      <View style={{ flex: 1 }}>
        <View style={{ height: 60 }} />
        <View style={{ paddingHorizontal: 24, paddingTop: 40 }}>
          <Text style={styles.title}>تسجيل الدخول إلى حسابك</Text>

          <InputField
            label="البريد الإلكتروني"
            placeholder="البريد الإلكتروني"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            textAlign="right"
          />

          <InputField
            label="كلمة المرور"
            placeholder="كلمة المرور"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textAlign="right"
          />

          <TouchableOpacity
            onPress={() => router.push("/forgetPass")}
            style={{ alignSelf: "flex-start", marginTop: 10 }}
          >
            <Text style={styles.forgotText}>نسيت كلمة المرور؟</Text>
          </TouchableOpacity>

          <CustomButton
            title="تسجيل الدخول"
            onPress={handleLogin}
            disabled={loading}
            className="mt-6"
            bgVariant="yellow"
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>تسجيل الدخول</Text>
            )}
          </CustomButton>

          <Link href="/sign-up" style={styles.signupLink}>
            <Text>
              ليس لديك حساب؟{" "}
              <Text style={styles.signupText}>إنشاء حساب جديد</Text>
            </Text>
          </Link>
        </View>
      </View>
    </ScrollView>
  );
};

export default SignIn;

const styles = StyleSheet.create({
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "right",
    marginBottom: 20,
    color: "#000",
  },
  forgotText: {
    fontSize: 14,
    color: "#FF914D",
    textAlign: "right",
  },
  buttonText: {
    fontWeight: "bold",
    color: "#fff",
    fontSize: 16,
  },
  signupLink: {
    marginTop: 40,
    alignSelf: "center",
  },
  signupText: {
    color: "#FF914D",
    fontWeight: "bold",
  },
});
