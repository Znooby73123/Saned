import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  FlatList,
} from "react-native";
import { useState } from "react";
import { router } from "expo-router";

const categories: string[] = [
  "Software",
  "Development",
  "Technology",
  "IT Software",
  "Social Science",
  "Language",
  "Arts & Humanities",
  "Reading",
  "Motion",
  "Tech",
  "Brand Design",
  "Health & Wellness",
];

export default function InterestScreen() {
  const [selected, setSelected] = useState<string[]>([]);

  const toggleSelect = (item: string) => {
    if (selected.includes(item)) {
      setSelected(selected.filter((i) => i !== item));
    } else {
      setSelected([...selected, item]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ماهي مجالات إهتماماتك؟</Text>
      <Text style={styles.subTitle}>
        حدد إهتماماتك لتصميم تجربة تعليمية مخصصة لتطوير مهاراتك وتوسيع معرفتك
        وخطواتك نحو التطور العلمي
      </Text>

      <Image
        source={require("@/assets/images/interest.png")}
        style={styles.image}
      />

      <FlatList
        data={categories}
        numColumns={3}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        contentContainerStyle={{ paddingBottom: 20 }}
        renderItem={({ item }: { item: string }) => (
          <TouchableOpacity
            onPress={() => toggleSelect(item)}
            style={[styles.tag, selected.includes(item) && styles.tagSelected]}
          >
            <Text
              style={[
                styles.tagText,
                selected.includes(item) && styles.tagTextSelected,
              ]}
            >
              {item}
            </Text>
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          router.push("../(root)/(tabs)/home");
        }}
      >
        <Text style={styles.buttonText}>استمرار</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    padding: 20,
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 100,
  },
  subTitle: {
    fontSize: 14,
    color: "#808080",
    textAlign: "center",
    marginVertical: 10,
  },
  image: {
    width: "100%",
    height: 200,
    resizeMode: "contain",
    marginVertical: 20,
    backgroundColor: "#FFFFFF",
    borderRadius: 10,
  },
  tag: {
    borderWidth: 1,
    borderColor: "#B0B0B0",
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  tagSelected: {
    backgroundColor: "#FF7A00",
    borderColor: "#FF7A00",
  },
  tagText: {
    fontSize: 13,
    color: "#000",
  },
  tagTextSelected: {
    color: "#FFF",
  },
  button: {
    backgroundColor: "#FFCC47",
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 15,
    alignItems: "center",
    alignSelf: "center",
    position: "absolute",
    bottom: 120,
    left: 20,
    right: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#000",
  },
});
