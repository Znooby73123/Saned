// import { useFonts } from "expo-font";
import { Stack } from "expo-router";

const Layout = () => {
  return (
    <Stack>
      <Stack.Screen name="welcome" options={{ headerShown: false }} />
      <Stack.Screen name="sign-up" options={{ headerShown: false }} />
      <Stack.Screen name="sign-in" options={{ headerShown: false }} />
      <Stack.Screen name="interest" options={{ headerShown: false }} />
      <Stack.Screen name="forgetPass" options={{ headerShown: false }} />
    </Stack>
  );
};

export default Layout;
