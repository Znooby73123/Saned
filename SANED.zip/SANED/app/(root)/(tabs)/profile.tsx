import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  I18nManager,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { useRouter } from "expo-router";

import DailyTasksScreen from "@/components/DailyTasks";
import ChallengesScreen from "@/components/ChallengesScreen";
import CoursesScreen from "@/components/CoursesScreen";

export default function ProfileScreen() {
  const [showDailyTasks, setShowDailyTasks] = useState(false);
  const [showChallenges, setShowChallenges] = useState(false);
  const [showCourses, setShowCourses] = useState(false);
  const router = useRouter();

  if (showDailyTasks) {
    return <DailyTasksScreen onBack={() => setShowDailyTasks(false)} />;
  }
  if (showChallenges) {
    return <ChallengesScreen onBack={() => setShowChallenges(false)} />;
  }
  if (showCourses) {
    return <CoursesScreen onBack={() => setShowCourses(false)} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          {/*<View style={styles.bellIcon}>*/}
          {/*  <Icon name="notifications-outline" size={24} color="#FF914D" />*/}
          {/*</View>*/}

          <Image
            source={require("@/assets/images/profile_image.png")}
            style={styles.avatar}
          />
          <Text style={styles.name}>نورة</Text>
          <Text style={styles.email}>norah@gmail.com</Text>
          <Text style={styles.subtitle}>طالبة علوم حاسب</Text>

          <TouchableOpacity style={styles.editIcon}>
            <Icon name="create-outline" size={20} color="#555" />
          </TouchableOpacity>
        </View>

        <View style={styles.menu}>
          <MenuItem
            title="مهامي"
            iconName="calendar-outline"
            onPress={() => setShowDailyTasks(true)}
          />
          <MenuItem
            title="التحديات السابقة"
            iconName="bookmark-outline"
            onPress={() => setShowChallenges(true)}
          />
          <MenuItem
            title="مقرراتي"
            iconName="book-outline"
            onPress={() => setShowCourses(true)}
          />
          <MenuItem
            title="تسجيل خروج"
            iconName="log-out-outline"
            onPress={() => router.push("/(auth)/welcome")}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

type MenuItemProps = {
  title: string;
  iconName: string;
  onPress: () => void;
};

const MenuItem = ({ title, iconName, onPress }: MenuItemProps) => (
  <TouchableOpacity onPress={onPress} style={styles.menuItem}>
    <View style={styles.itemLeft}>
      <Icon name={iconName} size={22} color="#555" style={styles.iconStyle} />
      <Text style={styles.menuText}>{title}</Text>
    </View>
    <Icon name="chevron-back-outline" size={20} color="#aaa" />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    alignItems: "center",
    paddingTop: 40,
    paddingBottom: 20,
    position: "relative",
  },
  bellIcon: {
    position: "absolute",
    top: 10,
    right: 20, // RTL
    backgroundColor: "#fff",
    padding: 6,
    borderRadius: 20,
    elevation: 2,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 50,
    backgroundColor: "#FFC9D6",
    marginBottom: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "right",
  },
  email: {
    color: "#666",
    textAlign: "right",
  },
  subtitle: {
    fontSize: 14,
    color: "#888",
    marginTop: 4,
    textAlign: "right",
  },
  editIcon: {
    position: "absolute",
    top: 100,
    left: 40, // RTL
    backgroundColor: "#eee",
    padding: 6,
    borderRadius: 20,
  },
  menu: {
    paddingHorizontal: 20,
    marginTop: 10,
  },
  menuItem: {
    flexDirection: "row-reverse", // RTL
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
    borderBottomColor: "#eee",
    borderBottomWidth: 1,
  },
  itemLeft: {
    flexDirection: "row-reverse", // RTL
    alignItems: "center",
  },
  menuText: {
    fontSize: 16,
    marginRight: 10, // spacing between icon and text
  },
  iconStyle: {
    // Renamed from 'icon' to 'iconStyle'
    marginLeft: I18nManager.isRTL ? 0 : 10,
    marginRight: I18nManager.isRTL ? 10 : 0,
  },
});
