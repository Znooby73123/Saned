import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
  Modal,
  TextInput,
  Image,
  I18nManager,
  SafeAreaView,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import { Calendar } from "react-native-calendars";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from "react-native-reanimated";
import {
  PanGestureHandler,
  GestureHandlerRootView,
  PanGestureHandlerGestureEvent,
} from "react-native-gesture-handler";
// import { Picker } from "@react-native-picker/picker";
import DateTimePicker from "@react-native-community/datetimepicker";

const { height } = Dimensions.get("window");

type DateObject = {
  dateString: string;
  day: number;
  month: number;
  year: number;
  timestamp: number;
};

type Event = {
  title: string;
  room: string;
  color: string;
  startTime: Date;
  endTime: Date;
};

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ScheduleScreen />
    </GestureHandlerRootView>
  );
}

function ScheduleScreen() {
  const [selected, setSelected] = useState<string>("2020-06-04");
  const [eventsData, setEventsData] = useState<Record<string, Event[]>>({
    "2020-06-04": [
      {
        title: "محاضرة تحليل عددي",
        room: "F33",
        color: "#4A90E2",
        startTime: new Date(2020, 5, 4, 10, 0), // Example start time: June 4, 2020, 10:00 AM
        endTime: new Date(2020, 5, 4, 12, 0), // Example end time: June 4, 2020, 12:00 PM
      },
      {
        title: "مناقشة مشروع الويب",
        room: "F40",
        color: "#FFB347",
        startTime: new Date(2020, 5, 4, 13, 0), // Example start time: June 4, 2020, 1:00 PM
        endTime: new Date(2020, 5, 4, 15, 0), // Example end time: June 4, 2020, 3:00 PM
      },
    ],
    "2020-06-05": [
      {
        title: "مراجعة نهائية",
        room: "F20",
        color: "#9B59B6",
        startTime: new Date(2020, 5, 5, 9, 0), // Example start time: June 5, 2020, 9:00 AM
        endTime: new Date(2020, 5, 5, 11, 0), // Example end time: June 5, 2020, 11:00 AM
      },
    ],
  });

  const [modalVisible, setModalVisible] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newRoom, setNewRoom] = useState("");
  const [newColor, setNewColor] = useState("#4CAF50");
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);
  const [startTime, setStartTime] = useState(new Date());
  const [endTime, setEndTime] = useState(new Date());

  const translateY = useSharedValue(0);
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  const onGestureEvent = (event: PanGestureHandlerGestureEvent) => {
    const translationY = event.nativeEvent.translationY;
    translateY.value = withSpring(translationY > 50 ? height * 0.35 : 0);
  };

  const handleAddEvent = () => {
    if (!newTitle || !newRoom) return;

    const newEvent: Event = {
      title: newTitle,
      room: newRoom,
      color: newColor,
      startTime,
      endTime,
    };

    setEventsData((prev) => {
      const updated = { ...prev };
      updated[selected] = updated[selected]
        ? [newEvent, ...updated[selected]]
        : [newEvent];
      return updated;
    });

    // Reset modal fields and close
    setNewTitle("");
    setNewRoom("");
    setNewColor("#4CAF50");
    setStartTime(new Date());
    setEndTime(new Date());
    setModalVisible(false);
  };

  const todayEvents = eventsData[selected] || [];

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ flex: 1, backgroundColor: "#fff", paddingHorizontal: 20 }}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>مهامي</Text>
          <TouchableOpacity>
            <Image
              source={require("@/assets/images/profile_image.png")} // Replace with your actual profile image path
              style={styles.profileImage}
            />
          </TouchableOpacity>
        </View>

        {/* Calendar */}
        <PanGestureHandler onGestureEvent={onGestureEvent}>
          <Animated.View style={[animatedStyle]}>
            {/*<View style={styles.dragIndicator}>*/}
            {/*  <Icon name="chevron-down-outline" size={20} color="#999" />*/}
            {/*</View>*/}

            <Calendar
              current={selected}
              onDayPress={(day: DateObject) => setSelected(day.dateString)}
              markedDates={{
                [selected]: { selected: true, selectedColor: "#FF914D" },
              }}
              theme={{
                textSectionTitleColor: "#000",
                selectedDayBackgroundColor: "#FF914D",
                todayTextColor: "#FF914D",
                dayTextColor: "#222",
                textDisabledColor: "#ccc",
              }}
              style={{ borderRadius: 16, elevation: 3, marginTop: 10 }}
            />
          </Animated.View>
        </PanGestureHandler>

        {/* Events List */}
        <ScrollView style={{ marginTop: 20, marginBottom: 80 }}>
          {todayEvents.map((event: Event, index: number) => (
            <View
              key={index}
              style={[styles.eventBoxBlue, { backgroundColor: "#F9F9F9" }]}
            >
              <EventCard
                title={event.title}
                room={event.room}
                borderColor={event.color}
                startTime={event.startTime}
                endTime={event.endTime}
              />
            </View>
          ))}
        </ScrollView>

        {/* Add Button */}
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setModalVisible(true)}
        >
          <Icon name="add" size={28} color="#fff" />
        </TouchableOpacity>

        {/* Add Event Modal */}
        <Modal
          visible={modalVisible}
          animationType="slide"
          transparent
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <Text style={styles.modalTitle}>إضافة حدث جديد</Text>
              <TextInput
                placeholder="عنوان الحدث"
                style={styles.input}
                value={newTitle}
                onChangeText={setNewTitle}
              />
              <TextInput
                placeholder="القاعة"
                style={styles.input}
                value={newRoom}
                onChangeText={setNewRoom}
              />
              {/*<Picker*/}
              {/*  selectedValue={newColor}*/}
              {/*  onValueChange={(itemValue) => setNewColor(itemValue)}*/}
              {/*  style={styles.picker}*/}
              {/*>*/}
              {/*  <Picker.Item label="اختر اللون" value="#4CAF50" />*/}
              {/*  <Picker.Item label="أزرق" value="#4A90E2" />*/}
              {/*  <Picker.Item label="برتقالي" value="#FFB347" />*/}
              {/*  <Picker.Item label="بنفسجي" value="#9B59B6" />*/}
              {/*  <Picker.Item label="أحمر" value="#E74C3C" />*/}
              {/*  <Picker.Item label="رمادي" value="#BDC3C7" />*/}
              {/*</Picker>*/}

              {/* Time Picker for Start Time */}
              <TouchableOpacity
                onPress={() => setShowStartPicker(true)}
                style={styles.timePickerButton}
              >
                <Text style={styles.timePickerText}>
                  وقت البدء:{" "}
                  {startTime.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </Text>
              </TouchableOpacity>
              {showStartPicker && (
                <DateTimePicker
                  value={startTime}
                  mode="time"
                  is24Hour={true}
                  display="default"
                  onChange={(event, selectedDate) => {
                    if (selectedDate) {
                      setStartTime(selectedDate);
                    }
                    setShowStartPicker(false);
                  }}
                />
              )}

              {/* Time Picker for End Time */}
              <TouchableOpacity
                onPress={() => setShowEndPicker(true)}
                style={styles.timePickerButton}
              >
                <Text style={styles.timePickerText}>
                  وقت الانتهاء:{" "}
                  {endTime.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </Text>
              </TouchableOpacity>
              {showEndPicker && (
                <DateTimePicker
                  value={endTime}
                  mode="time"
                  is24Hour={true}
                  display="default"
                  onChange={(event, selectedDate) => {
                    if (selectedDate) {
                      setEndTime(selectedDate);
                    }
                    setShowEndPicker(false);
                  }}
                />
              )}

              <TouchableOpacity
                style={styles.submitButton}
                onPress={handleAddEvent}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>إضافة</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

type EventCardProps = {
  title: string;
  room: string;
  borderColor?: string;
  startTime: Date;
  endTime: Date;
};

const EventCard = ({
  title,
  room,
  borderColor = "#ccc",
  startTime,
  endTime,
}: EventCardProps) => (
  <View style={[styles.eventCard, { borderColor }]}>
    <Text style={styles.eventTime}>{`${startTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })} - ${endTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`}</Text>
    <Text style={styles.eventTitle}>{title}</Text>
    <Text style={styles.eventRoom}>المبنى الجديد {room}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    // marginTop: 20,
  },
  header: {
    // flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    // marginBottom: 10,
    // padding: 20,
    backgroundColor: "#fff",
    marginTop: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    left: 140,
  },
  profileImage: {
    width: 40,
    height: 40,
    borderRadius: 50,
  },
  headerHome: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    marginTop: 80,
    // justifyContent: "flex-end", // 👈 Align items to the right
  },
  bellHome: {
    backgroundColor: "#fff",
    padding: 8,
    borderRadius: 20,
    elevation: 2,
  },
  userHome: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    alignSelf: "center",
  },
  avatarHome: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#FFC9D6",
    marginLeft: 10,
  },
  eventBoxBlue: {
    borderRadius: 16,
    padding: 10,
    marginBottom: 10,
  },
  eventCard: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  eventTime: {
    fontSize: 12,
    color: "#888",
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginTop: 4,
  },
  eventRoom: {
    fontSize: 13,
    color: "#666",
    marginTop: 2,
  },
  dragIndicator: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 5,
  },
  addButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    backgroundColor: "#FF914D",
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "#000000aa",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 20,
    width: "80%",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
  },
  picker: {
    height: 50,
    width: "100%",
    marginBottom: 10,
  },
  timePickerButton: {
    padding: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 10,
  },
  timePickerText: {
    fontSize: 16,
  },
  submitButton: {
    backgroundColor: "#FF914D",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },
});
