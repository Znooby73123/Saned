import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import ChatScreen from "@/components/ChatScreen";

const notifications = [
  {
    id: "1",
    name: "فريق الدعم",
    time: "الأحد - 12:40م",
    message: "لقد تم حل مشكلتك، سعدنا بخدمتك...",
  },
  // {
  //   id: "2",
  //   name: "المعلم علي",
  //   time: "السبت - 3:15م",
  //   message: "تذكير: لديك جلسة تدريب اليوم في الساعة 4 مساءً.",
  // },
  // {
  //   id: "3",
  //   name: "المعلمه ريم",
  //   time: "الجمعة - 9:00ص",
  //   message: "تم إصدار دورة جديدة في مجال البرمجة.",
  // },
];

const NotificationScreen = () => {
  const [showChatScreen, setShowChatScreen] = useState(false);

  if (showChatScreen) {
    return <ChatScreen onBack={() => setShowChatScreen(false)} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>الإشعارات</Text>

      <View style={styles.listContainer}>
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setShowChatScreen(true)} // ✅ Fix here
              activeOpacity={0.8}
            >
              <View style={styles.notification}>
                <Image
                  source={require("@/assets/images/memoji3.png")}
                  style={styles.avatar}
                />
                <View>
                  <Text style={styles.name}>{item.name}</Text>
                  <Text style={styles.message}>{item.message}</Text>
                  <Text style={styles.time}>{item.time}</Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    // paddingTop: 40,
    // paddingHorizontal: 20,
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 30,
    color: "#333",
    marginTop: 20,
  },
  listContainer: {
    flex: 1,
  },
  notification: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
    backgroundColor: "#e6f7ff",
    padding: 12,
    borderRadius: 12,
    paddingHorizontal: 20,
    width: "90%",
    // justifyContent: "space-between",
    alignSelf: "center",
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  name: {
    fontWeight: "bold",
    fontSize: 16,
    marginBottom: 2,
  },
  message: {
    fontSize: 14,
    color: "#555",
    marginBottom: 2,
  },
  time: {
    fontSize: 12,
    color: "#999",
  },
});

export default NotificationScreen;
