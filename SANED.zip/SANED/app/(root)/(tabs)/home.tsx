import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from "react-native";
import VideoScreen from "@/components/VideoScreen";
import VideoDetailsScreen from "@/components/VideoDetailsScreen";

const videos = [
  {
    id: "1",
    image: require("@/assets/images/db.png"),
    title: "أساسيات قواعد البيانات",
    author: "محمد السويح",
  },
  {
    id: "2",
    image: require("@/assets/images/purple.png"),
    title: "شروحات الرياضيات",
    author: "Neso Academy",
  },
];

export default function HomeScreen() {
  const [showVideoScreen, setShowVideoScreen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<null | (typeof videos)[0]>(
    null,
  );

  if (showVideoScreen) {
    return <VideoScreen onBack={() => setShowVideoScreen(false)} />;
  }

  if (selectedVideo) {
    return (
      <VideoDetailsScreen
        image={selectedVideo.image}
        title={selectedVideo.title}
        onBack={() => setSelectedVideo(null)}
      />
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container}>
        <Text style={styles.welcome}>
          أهلًا وسهلًا <Text style={styles.name}>نورة</Text>
        </Text>

        <Text style={styles.sectionTitle}>موادك الدراسية</Text>
        <View style={styles.buttonsContainer}>
          <TouchableOpacity style={styles.subjectButton}>
            <Text style={styles.buttonText}>شبكات</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.subjectButton}>
            <Text style={styles.buttonText}>نظم معلومات</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.subjectButton}>
            <Text style={styles.buttonText}>OOP</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.subjectButton}>
            <Text style={styles.buttonText}>نظم تشغيل</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.videoHeader}>
          <Text style={styles.sectionTitle}>الفيديوهات التعليمية!</Text>
          <TouchableOpacity onPress={() => setShowVideoScreen(true)}>
            <Text style={styles.subText}>اضغط للمزيد</Text>
          </TouchableOpacity>
        </View>

        {videos.map((video) => (
          <TouchableOpacity
            key={video.id}
            onPress={() => setSelectedVideo(video)}
            style={styles.videoCard}
          >
            <Image source={video.image} style={styles.videoImage} />
            <Text style={styles.videoTitle}>{video.title}</Text>
            <Text style={styles.videoAuthor}>{video.author}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: "#fff", flex: 1 },
  welcome: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "right",
    marginBottom: 20,
  },
  name: { color: "#f59e0b" },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "right",
    marginTop: 20,
  },
  videoHeader: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
  },
  subText: {
    color: "#f59e0b",
    fontSize: 14,
    fontWeight: "bold",
  },
  buttonsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginTop: 10,
  },
  subjectButton: {
    backgroundColor: "#f59e0b",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    margin: 5,
  },
  buttonText: { color: "white", fontWeight: "bold" },
  videoCard: {
    backgroundColor: "#f3f3f3",
    padding: 10,
    borderRadius: 12,
    marginTop: 15,
  },
  videoImage: {
    width: "100%",
    height: 150,
    borderRadius: 10,
  },
  videoTitle: {
    textAlign: "right",
    marginTop: 10,
    fontWeight: "bold",
    fontSize: 16,
  },
  videoAuthor: {
    textAlign: "right",
    color: "#666",
    marginTop: 4,
    fontSize: 13,
  },
});
