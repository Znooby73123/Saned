// app/_layout.tsx
import { Tabs } from "expo-router";
import CustomTabBar from "@/components/CustomTabBar";

export default function Layout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
      }}
      tabBar={(props) => <CustomTabBar {...props} />}
    />
  );
}
