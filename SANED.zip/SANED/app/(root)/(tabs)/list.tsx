import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from "react-native";
import DailyTasksScreen from "@/components/DailyTasks";
import VideoScreen from "@/components/VideoScreen";
import ChallengesScreen from "@/components/ChallengesScreen"; // Assuming this is the correct path

export default function MenuScreen() {
  const [showDailyTasks, setShowDailyTasks] = useState(false);
  const [showVideos, setShowVideos] = useState(false);
  const [showChallenges, setShowChallenges] = useState(false);

  if (showDailyTasks) {
    return <DailyTasksScreen onBack={() => setShowDailyTasks(false)} />;
  }

  if (showVideos) {
    return <VideoScreen onBack={() => setShowVideos(false)} />;
  }

  if (showChallenges) {
    return <ChallengesScreen onBack={() => setShowChallenges(false)} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container}>
        <Image
          source={require("@/assets/images/profile_image.png")}
          style={styles.profileIcon}
        />
        <Text style={styles.title}>القائمة</Text>

        <TouchableOpacity
          style={styles.cardYellow}
          onPress={() => setShowDailyTasks(true)}
        >
          <View style={styles.cardTextContainer}>
            <Text style={styles.cardTitle}>مهامي اليومية</Text>
            <Text style={styles.cardSubtitle}>
              أضف مهامك اليومية وانجزها الآن!
            </Text>
          </View>
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/2920/2920261.png",
            }}
            style={styles.cardImage}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cardBlue}
          onPress={() => setShowVideos(true)}
        >
          <View style={styles.cardTextContainer}>
            <Text style={styles.cardTitle}>الفيديوهات التعليمية</Text>
            <Text style={styles.cardSubtitle}>جمعنا لكم أفضل الشروحات!</Text>
          </View>
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
            }}
            style={styles.cardImage}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cardOrange}
          onPress={() => setShowChallenges(true)}
        >
          <View style={styles.cardTextContainer}>
            <Text style={styles.cardTitle}>التحديات</Text>
            <Text style={styles.cardSubtitle}>اكتشف واختبر مدى فهمك!</Text>
          </View>
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/3159/3159066.png",
            }}
            style={styles.cardImage}
          />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    padding: 20,
    flex: 1,
  },
  profileIcon: {
    width: 40,
    height: 40,
    alignSelf: "flex-end",
    marginBottom: 10,
    borderRadius: 50,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 10,
    color: "#000",
  },
  cardYellow: {
    backgroundColor: "#FFD36F",
    borderRadius: 20,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    padding: 15,
    alignItems: "center",
    marginVertical: 10,
  },
  cardBlue: {
    backgroundColor: "#B9E3FF",
    borderRadius: 20,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    padding: 15,
    alignItems: "center",
    marginVertical: 10,
  },
  cardOrange: {
    backgroundColor: "#FFA86F",
    borderRadius: 20,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    padding: 15,
    alignItems: "center",
    marginVertical: 10,
  },
  cardImage: {
    width: 60,
    height: 60,
    marginLeft: 10,
  },
  cardTextContainer: {
    flex: 1,
    alignItems: "flex-end",
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#000",
  },
  cardSubtitle: {
    fontSize: 14,
    color: "#444",
    marginTop: 5,
  },
});
