import { StatusBar } from "expo-status-bar";
import { Stack } from "expo-router";

const Layout = () => {
  return (
    <>
      <StatusBar style="dark" />
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      </Stack>
    </>
  );
};

export default Layout;
