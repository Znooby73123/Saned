// https://docs.expo.dev/guides/using-eslint/
module.exports = {
  extends: "expo",
  ignorePatterns: ["/dist/*"],
  settings: {
    "import/resolver": {
      typescript: {}, // this makes ESLint understand your tsconfig paths
    },
  },
};
